# Personal-Carbon-Calculator
A simple Streamlit app for calculating the Carbon Footprint. 
